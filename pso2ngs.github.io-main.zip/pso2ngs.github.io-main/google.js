onload = () => {
  setTimeout(() => {
    location.href = 'https://www.google.com/';
  }, 5000);
}
